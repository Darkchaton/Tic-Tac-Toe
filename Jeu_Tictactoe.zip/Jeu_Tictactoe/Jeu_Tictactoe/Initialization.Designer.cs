﻿
namespace Jeu_Tictactoe
{
    partial class Initialization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pseudo1 = new System.Windows.Forms.TextBox();
            this.Pseudo2 = new System.Windows.Forms.TextBox();
            this.labelPseudo1 = new System.Windows.Forms.Label();
            this.labelPseudo2 = new System.Windows.Forms.Label();
            this.buttonDemarrer = new System.Windows.Forms.Button();
            this.radioButtonX = new System.Windows.Forms.RadioButton();
            this.radioButtonO = new System.Windows.Forms.RadioButton();
            this.labelChoixSigne = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Pseudo1
            // 
            this.Pseudo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pseudo1.Location = new System.Drawing.Point(64, 104);
            this.Pseudo1.Name = "Pseudo1";
            this.Pseudo1.Size = new System.Drawing.Size(269, 22);
            this.Pseudo1.TabIndex = 0;
            this.Pseudo1.TextChanged += new System.EventHandler(this.Pseudo1_TextChanged);
            // 
            // Pseudo2
            // 
            this.Pseudo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pseudo2.Location = new System.Drawing.Point(473, 104);
            this.Pseudo2.Name = "Pseudo2";
            this.Pseudo2.Size = new System.Drawing.Size(269, 22);
            this.Pseudo2.TabIndex = 1;
            this.Pseudo2.TextChanged += new System.EventHandler(this.Pseudo2_TextChanged);
            // 
            // labelPseudo1
            // 
            this.labelPseudo1.AutoSize = true;
            this.labelPseudo1.Font = new System.Drawing.Font("Commons", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPseudo1.Location = new System.Drawing.Point(49, 72);
            this.labelPseudo1.Name = "labelPseudo1";
            this.labelPseudo1.Size = new System.Drawing.Size(306, 20);
            this.labelPseudo1.TabIndex = 2;
            this.labelPseudo1.Text = "Entrer le pseudo du premier joueur :";
            // 
            // labelPseudo2
            // 
            this.labelPseudo2.AutoSize = true;
            this.labelPseudo2.Font = new System.Drawing.Font("Commons", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPseudo2.Location = new System.Drawing.Point(453, 72);
            this.labelPseudo2.Name = "labelPseudo2";
            this.labelPseudo2.Size = new System.Drawing.Size(322, 20);
            this.labelPseudo2.TabIndex = 3;
            this.labelPseudo2.Text = "Entrer le pseudo du deuxième joueur :";
            // 
            // buttonDemarrer
            // 
            this.buttonDemarrer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonDemarrer.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.buttonDemarrer.FlatAppearance.BorderSize = 3;
            this.buttonDemarrer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDemarrer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDemarrer.Location = new System.Drawing.Point(320, 299);
            this.buttonDemarrer.Name = "buttonDemarrer";
            this.buttonDemarrer.Size = new System.Drawing.Size(155, 57);
            this.buttonDemarrer.TabIndex = 4;
            this.buttonDemarrer.Text = "Commencer !";
            this.buttonDemarrer.UseVisualStyleBackColor = false;
            this.buttonDemarrer.Click += new System.EventHandler(this.buttonDemarrer_Click_1);
            // 
            // radioButtonX
            // 
            this.radioButtonX.AutoSize = true;
            this.radioButtonX.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.radioButtonX.FlatAppearance.BorderSize = 9;
            this.radioButtonX.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.radioButtonX.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radioButtonX.Font = new System.Drawing.Font("Ravie", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonX.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.radioButtonX.Location = new System.Drawing.Point(320, 231);
            this.radioButtonX.Name = "radioButtonX";
            this.radioButtonX.Size = new System.Drawing.Size(62, 32);
            this.radioButtonX.TabIndex = 5;
            this.radioButtonX.TabStop = true;
            this.radioButtonX.Text = "X";
            this.radioButtonX.UseVisualStyleBackColor = true;
            this.radioButtonX.CheckedChanged += new System.EventHandler(this.radioButtonX_CheckedChanged);
            // 
            // radioButtonO
            // 
            this.radioButtonO.AutoSize = true;
            this.radioButtonO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.radioButtonO.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonO.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radioButtonO.Font = new System.Drawing.Font("Ravie", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonO.Location = new System.Drawing.Point(437, 231);
            this.radioButtonO.Name = "radioButtonO";
            this.radioButtonO.Size = new System.Drawing.Size(59, 32);
            this.radioButtonO.TabIndex = 6;
            this.radioButtonO.TabStop = true;
            this.radioButtonO.Text = "O";
            this.radioButtonO.UseVisualStyleBackColor = false;
            this.radioButtonO.CheckedChanged += new System.EventHandler(this.radioButtonO_CheckedChanged);
            // 
            // labelChoixSigne
            // 
            this.labelChoixSigne.AutoSize = true;
            this.labelChoixSigne.Font = new System.Drawing.Font("Commons", 10.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelChoixSigne.Location = new System.Drawing.Point(246, 194);
            this.labelChoixSigne.Name = "labelChoixSigne";
            this.labelChoixSigne.Size = new System.Drawing.Size(312, 20);
            this.labelChoixSigne.TabIndex = 7;
            this.labelChoixSigne.Text = "Joueur 1, veuillez choisir votre signe :";
            // 
            // Initialization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(835, 418);
            this.Controls.Add(this.labelChoixSigne);
            this.Controls.Add(this.radioButtonO);
            this.Controls.Add(this.radioButtonX);
            this.Controls.Add(this.buttonDemarrer);
            this.Controls.Add(this.labelPseudo2);
            this.Controls.Add(this.labelPseudo1);
            this.Controls.Add(this.Pseudo2);
            this.Controls.Add(this.Pseudo1);
            this.DoubleBuffered = true;
            this.Name = "Initialization";
            this.Text = "Bienvenue";
            this.Load += new System.EventHandler(this.tictactoe_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Pseudo1;
        private System.Windows.Forms.TextBox Pseudo2;
        private System.Windows.Forms.Label labelPseudo1;
        private System.Windows.Forms.Label labelPseudo2;
        private System.Windows.Forms.Button buttonDemarrer;
        private System.Windows.Forms.RadioButton radioButtonX;
        private System.Windows.Forms.RadioButton radioButtonO;
        private System.Windows.Forms.Label labelChoixSigne;
    }
}

