﻿
namespace Jeu_Tictactoe
{
    partial class Jeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTictactoe = new System.Windows.Forms.Label();
            this.labelPartie = new System.Windows.Forms.Label();
            this.buttonRejouer = new System.Windows.Forms.Button();
            this.buttonHistorique = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.labelPseudo1 = new System.Windows.Forms.Label();
            this.labelPseudo2 = new System.Windows.Forms.Label();
            this.buttonQuitter = new System.Windows.Forms.Button();
            this.labelVraiPseudo2 = new System.Windows.Forms.Label();
            this.labelJoueurActif = new System.Windows.Forms.Label();
            this.labelCreateur = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelTictactoe
            // 
            this.labelTictactoe.AutoSize = true;
            this.labelTictactoe.Font = new System.Drawing.Font("November", 55.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTictactoe.ForeColor = System.Drawing.Color.Lime;
            this.labelTictactoe.Location = new System.Drawing.Point(285, 9);
            this.labelTictactoe.Name = "labelTictactoe";
            this.labelTictactoe.Size = new System.Drawing.Size(693, 117);
            this.labelTictactoe.TabIndex = 0;
            this.labelTictactoe.Text = "TIC - TAC - TOE";
            this.labelTictactoe.Click += new System.EventHandler(this.labelTictactoe_Click);
            // 
            // labelPartie
            // 
            this.labelPartie.AutoSize = true;
            this.labelPartie.Font = new System.Drawing.Font("Valken", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPartie.ForeColor = System.Drawing.Color.SteelBlue;
            this.labelPartie.Location = new System.Drawing.Point(870, 177);
            this.labelPartie.Name = "labelPartie";
            this.labelPartie.Size = new System.Drawing.Size(108, 34);
            this.labelPartie.TabIndex = 2;
            this.labelPartie.Text = "Partie:";
            this.labelPartie.Click += new System.EventHandler(this.labelPartie_Click);
            // 
            // buttonRejouer
            // 
            this.buttonRejouer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonRejouer.Font = new System.Drawing.Font("Tarzan", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRejouer.Location = new System.Drawing.Point(853, 280);
            this.buttonRejouer.Name = "buttonRejouer";
            this.buttonRejouer.Size = new System.Drawing.Size(144, 37);
            this.buttonRejouer.TabIndex = 3;
            this.buttonRejouer.Text = "Rejouer";
            this.buttonRejouer.UseVisualStyleBackColor = false;
            this.buttonRejouer.Click += new System.EventHandler(this.buttonRejouer_Click);
            // 
            // buttonHistorique
            // 
            this.buttonHistorique.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonHistorique.Font = new System.Drawing.Font("Tarzan", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHistorique.Location = new System.Drawing.Point(853, 342);
            this.buttonHistorique.Name = "buttonHistorique";
            this.buttonHistorique.Size = new System.Drawing.Size(144, 36);
            this.buttonHistorique.TabIndex = 4;
            this.buttonHistorique.Text = "Historique";
            this.buttonHistorique.UseVisualStyleBackColor = false;
            this.buttonHistorique.Click += new System.EventHandler(this.buttonHistorique_Click);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b2.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b2.FlatAppearance.BorderSize = 3;
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b2.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.b2.Location = new System.Drawing.Point(502, 159);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(101, 101);
            this.b2.TabIndex = 6;
            this.b2.Text = " ";
            this.b2.UseVisualStyleBackColor = false;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b3.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b3.FlatAppearance.BorderSize = 3;
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b3.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.b3.Location = new System.Drawing.Point(629, 159);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(101, 101);
            this.b3.TabIndex = 7;
            this.b3.Text = " ";
            this.b3.UseVisualStyleBackColor = false;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b4.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b4.FlatAppearance.BorderSize = 3;
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b4.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.ForeColor = System.Drawing.Color.Fuchsia;
            this.b4.Location = new System.Drawing.Point(378, 277);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(101, 101);
            this.b4.TabIndex = 8;
            this.b4.Text = " ";
            this.b4.UseVisualStyleBackColor = false;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b5.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b5.FlatAppearance.BorderSize = 3;
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b5.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.ForeColor = System.Drawing.Color.Yellow;
            this.b5.Location = new System.Drawing.Point(502, 277);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(101, 101);
            this.b5.TabIndex = 9;
            this.b5.Text = " ";
            this.b5.UseVisualStyleBackColor = false;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b6.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b6.FlatAppearance.BorderSize = 3;
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b6.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.b6.Location = new System.Drawing.Point(629, 277);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(101, 101);
            this.b6.TabIndex = 10;
            this.b6.Text = " ";
            this.b6.UseVisualStyleBackColor = false;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b7.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b7.FlatAppearance.BorderSize = 3;
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b7.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.ForeColor = System.Drawing.Color.Cyan;
            this.b7.Location = new System.Drawing.Point(378, 393);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(101, 101);
            this.b7.TabIndex = 11;
            this.b7.Text = " ";
            this.b7.UseVisualStyleBackColor = false;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b8.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b8.FlatAppearance.BorderSize = 3;
            this.b8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b8.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.ForeColor = System.Drawing.Color.DeepPink;
            this.b8.Location = new System.Drawing.Point(502, 393);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(101, 101);
            this.b8.TabIndex = 12;
            this.b8.Text = " ";
            this.b8.UseVisualStyleBackColor = false;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b9.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b9.FlatAppearance.BorderSize = 3;
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b9.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.ForeColor = System.Drawing.Color.DarkOrange;
            this.b9.Location = new System.Drawing.Point(629, 393);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(101, 101);
            this.b9.TabIndex = 13;
            this.b9.Text = " ";
            this.b9.UseVisualStyleBackColor = false;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.b1.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.b1.FlatAppearance.BorderSize = 3;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Font = new System.Drawing.Font("PR Celtic Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.ForeColor = System.Drawing.Color.OrangeRed;
            this.b1.Location = new System.Drawing.Point(378, 158);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(101, 101);
            this.b1.TabIndex = 14;
            this.b1.Text = " ";
            this.b1.UseVisualStyleBackColor = false;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // labelPseudo1
            // 
            this.labelPseudo1.AutoSize = true;
            this.labelPseudo1.Font = new System.Drawing.Font("Toledo", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPseudo1.ForeColor = System.Drawing.Color.DarkGreen;
            this.labelPseudo1.Location = new System.Drawing.Point(13, 185);
            this.labelPseudo1.Name = "labelPseudo1";
            this.labelPseudo1.Size = new System.Drawing.Size(89, 25);
            this.labelPseudo1.TabIndex = 15;
            this.labelPseudo1.Text = " labelJ1";
            this.labelPseudo1.Click += new System.EventHandler(this.labelPseudo1_Click);
            // 
            // labelPseudo2
            // 
            this.labelPseudo2.AutoSize = true;
            this.labelPseudo2.Font = new System.Drawing.Font("Toledo", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPseudo2.ForeColor = System.Drawing.Color.DarkGreen;
            this.labelPseudo2.Location = new System.Drawing.Point(13, 198);
            this.labelPseudo2.Name = "labelPseudo2";
            this.labelPseudo2.Size = new System.Drawing.Size(0, 26);
            this.labelPseudo2.TabIndex = 17;
            // 
            // buttonQuitter
            // 
            this.buttonQuitter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonQuitter.Font = new System.Drawing.Font("Tarzan", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQuitter.Location = new System.Drawing.Point(853, 421);
            this.buttonQuitter.Name = "buttonQuitter";
            this.buttonQuitter.Size = new System.Drawing.Size(144, 36);
            this.buttonQuitter.TabIndex = 19;
            this.buttonQuitter.Text = "Quitter";
            this.buttonQuitter.UseVisualStyleBackColor = false;
            this.buttonQuitter.Click += new System.EventHandler(this.buttonQuitter_Click);
            // 
            // labelVraiPseudo2
            // 
            this.labelVraiPseudo2.AutoSize = true;
            this.labelVraiPseudo2.Font = new System.Drawing.Font("Toledo", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVraiPseudo2.ForeColor = System.Drawing.Color.Orange;
            this.labelVraiPseudo2.Location = new System.Drawing.Point(13, 301);
            this.labelVraiPseudo2.Name = "labelVraiPseudo2";
            this.labelVraiPseudo2.Size = new System.Drawing.Size(89, 25);
            this.labelVraiPseudo2.TabIndex = 20;
            this.labelVraiPseudo2.Text = " labelJ2";
            this.labelVraiPseudo2.Click += new System.EventHandler(this.labelVraiPseudo2_Click);
            // 
            // labelJoueurActif
            // 
            this.labelJoueurActif.AutoSize = true;
            this.labelJoueurActif.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJoueurActif.ForeColor = System.Drawing.Color.Coral;
            this.labelJoueurActif.Location = new System.Drawing.Point(345, 119);
            this.labelJoueurActif.Name = "labelJoueurActif";
            this.labelJoueurActif.Size = new System.Drawing.Size(281, 33);
            this.labelJoueurActif.TabIndex = 21;
            this.labelJoueurActif.Text = "labelJoueurActif";
            // 
            // labelCreateur
            // 
            this.labelCreateur.AutoSize = true;
            this.labelCreateur.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCreateur.ForeColor = System.Drawing.Color.Maroon;
            this.labelCreateur.Location = new System.Drawing.Point(319, 531);
            this.labelCreateur.Name = "labelCreateur";
            this.labelCreateur.Size = new System.Drawing.Size(541, 28);
            this.labelCreateur.TabIndex = 23;
            this.labelCreateur.Text = "Jeu programmé par Amélia Dulac avec l\'aide de Pamela Kissok";
            // 
            // Jeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1138, 592);
            this.Controls.Add(this.labelCreateur);
            this.Controls.Add(this.labelJoueurActif);
            this.Controls.Add(this.labelVraiPseudo2);
            this.Controls.Add(this.buttonQuitter);
            this.Controls.Add(this.labelPseudo2);
            this.Controls.Add(this.labelPseudo1);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.buttonHistorique);
            this.Controls.Add(this.buttonRejouer);
            this.Controls.Add(this.labelPartie);
            this.Controls.Add(this.labelTictactoe);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Roland", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Jeu";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Jeu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTictactoe;
        private System.Windows.Forms.Label labelPartie;
        private System.Windows.Forms.Button buttonRejouer;
        private System.Windows.Forms.Button buttonHistorique;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Label labelPseudo1;
        private System.Windows.Forms.Label labelPseudo2;
        private System.Windows.Forms.Button buttonQuitter;
        private System.Windows.Forms.Label labelVraiPseudo2;
        private System.Windows.Forms.Label labelJoueurActif;
        private System.Windows.Forms.Label labelCreateur;
    }
}