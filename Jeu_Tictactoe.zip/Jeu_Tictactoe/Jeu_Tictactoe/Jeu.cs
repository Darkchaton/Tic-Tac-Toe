﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Jeu_Tictactoe.Joueur;
using static Jeu_Tictactoe.Initialization;

namespace Jeu_Tictactoe
{
    public partial class Jeu : Form
    {
        // Declaration
        private List<Button> listeBoutons;

        private Joueur joueur1;
        private Joueur joueur2;
        private PartieEnCours partieEnCours;

        public Jeu(PartieEnCours partieEnCours)
        {
            InitializeComponent();

            // Conserver les informations de la partie en cours
            this.partieEnCours = partieEnCours;
            this.joueur1 = partieEnCours.Joueur1;
            this.joueur2 = partieEnCours.Joueur2;

            // Initialisation de la liste de boutons
            listeBoutons = new List<Button>
        {
            b1, b2, b3, b4, b5, b6, b7, b8, b9
        };

            // Activer et assigner les événements pour tous les boutons dans la liste de boutons en utilisant la fonction "Bouton_Click" 
            foreach (Button bouton in listeBoutons)
            {
                bouton.Click += Bouton_Click;
            }
        }

        // Initialiser les labels au DÉBUT de la partie (Sinon elles n'apparaissent pas sur le form du Jeu)
        private void Jeu_Load(object sender, EventArgs e)
        {
            JouerPartie();
        }

        private void JouerPartie()
        {
            labelPseudo1.Text = partieEnCours.Joueur1.informationJoueur();
            labelVraiPseudo2.Text = partieEnCours.Joueur2.informationJoueur();
            labelJoueurActif.Text = partieEnCours.JoueurActif.JoueurEnCours();
            labelPartie.Text = Partie.InformationHistorique();
            labelPartie.Text = $"Partie : {Partie.nombrePartieJouees}";
        }

        // Fonction Bouton_Click
        private void Bouton_Click(object sender, EventArgs e)
        {
            Button bouton = (Button)sender;

            // Vérifier si le bouton est déjà cliqué
            if (bouton.Text != " ")
                return;

            // Vérifier si le joueur est actif
            char symboleJoueurActif = partieEnCours.JoueurActif.Symbole;
            bouton.Text = symboleJoueurActif.ToString();
            bouton.Enabled = false;
            partieEnCours.JoueurActif.BoutonActive.Add(bouton);

            // Vérifier si le joueur a gagné
            if (partieEnCours.JoueurActif.estGagnant(listeBoutons))
            {
                MessageBox.Show($"{partieEnCours.JoueurActif.Pseudo} a gagné ! Bien joué !");

                Partie.historiquePartie.Add(partieEnCours);
                Partie.nombrePartieJouees++;
                //Partie.nombreCredits++;
                partieEnCours.JoueurActif.IncrementerCredit(); // Augmente le nombre de crédits du joueur gagnant
                 

                NouvellePartie();
                return;
            }

            // Vérifier s'il y a une partie nulle (tous les boutons sont actifs)
            if (!listeBoutons.Any(b => b.Text == " "))
            {
                MessageBox.Show("Partie nulle ! Recommençons.");
                Partie.historiquePartie.Add(partieEnCours);
                NouvellePartie();
                return;
            }

            // Passer au prochain joueur
            partieEnCours.JoueurActif = partieEnCours.JoueurActif == partieEnCours.Joueur1 ? partieEnCours.Joueur2 : partieEnCours.Joueur1;

            // Mettre à jour l'étiquette affichant le joueur actif
            labelJoueurActif.Text = $"En attente de {partieEnCours.JoueurActif.Pseudo}...";
        }

        private void b1_Click(object sender, EventArgs e)
        {
        }
        private void b2_Click(object sender, EventArgs e)
        {
        }
        private void b3_Click(object sender, EventArgs e)
        {
        }
        private void b4_Click(object sender, EventArgs e)
        {
        }
        private void b5_Click(object sender, EventArgs e)
        {
        }
        private void b6_Click(object sender, EventArgs e)
        {
        }
        private void b7_Click(object sender, EventArgs e)
        {
        }
        private void b8_Click(object sender, EventArgs e)
        {
        }
        private void b9_Click(object sender, EventArgs e)
        {
        }

        //Bouton de référence à l'historique des parties jouées, pour les afficher
        private void buttonHistorique_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Partie.InformationHistorique());
        }

        // Bouton pour Rejouer
        private void buttonRejouer_Click(object sender, EventArgs e)
        {
            Partie.historiquePartie.Add(partieEnCours);
            Partie.nombrePartieJouees++;
            NouvellePartie();
        }
        
        // Fonction de renouvellement
        private void NouvellePartie()
        {
            foreach (Button bouton in listeBoutons)
            {
                bouton.Text = " "; // Effacer le texte des boutons
                bouton.Enabled = true; // Réactive les boutons ensuite
            }

            // Efface les informations enregistrés par les boutons dans l'ancienne partie
            partieEnCours.Joueur1.BoutonActive.Clear();
            partieEnCours.Joueur2.BoutonActive.Clear();
            partieEnCours.JoueurActif = partieEnCours.Joueur1; //Remet le début de partie au premier joueur

            // Remet les labels à neuf
            labelJoueurActif.Text = $"En attente de {partieEnCours.JoueurActif.Pseudo}...";
            labelPartie.Text = Partie.InformationHistorique();
            labelPartie.Text = $"Partie : {Partie.nombrePartieJouees}";

            JouerPartie();
        }
     
        private void buttonQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //  Fonctions inutiles à cause des missclicks
        private void labelJoueur1Score_Click(object sender, EventArgs e)
        {
        }
        private void labelScore_Click(object sender, EventArgs e)
        {
        }
        private void labelTictactoe_Click(object sender, EventArgs e)
        {
        }
        private void labelPseudo1_Click(object sender, EventArgs e)
        {
        }
        private void labelVraiPseudo2_Click(object sender, EventArgs e)
        {
        }
        private void labelPartie_Click(object sender, EventArgs e)
        {
        }
    }
 }

