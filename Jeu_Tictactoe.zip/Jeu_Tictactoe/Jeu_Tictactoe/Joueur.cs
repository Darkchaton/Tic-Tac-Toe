﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jeu_Tictactoe
{
    public class Joueur : Ijoueur
    {
        // Déclaration

        private char symbole; // Symbole du joueur (X ou O)
        private string pseudo; // Pseudo du joueur
        private int credit; // Crédit du joueur à chaque fois qu'il gagne une partie / score

        // Initialisation
        public List<Button> BoutonActive { get; } = new List<Button>();

        public Joueur(char symbole, string pseudo)
        {
            this.symbole = symbole;
            this.pseudo = pseudo;
            this.credit = 0;
        }
        public string Pseudo
        {
            get { return pseudo; }
        }
        public int Credit
        {
            get { return credit; }
            set { credit = value; }
        }
        public char Symbole
        {
            get { return symbole; }
            set { symbole = value; }
        }

        // Fonction pour vider la liste des boutons actifs du joueur (Appelée dans la classe Jeu pour vider les boutons des joueurs) 
        public void ViderBoutonActive()
        {
            this.BoutonActive.Clear();
        }

        public bool estGagnant(List<Button> listeBoutons)
        {
            // Lignes gagnantes
            if (BoutonActive.Exists(b => b.Name == "b1") && BoutonActive.Exists(b => b.Name == "b2") && BoutonActive.Exists(b => b.Name == "b3"))
                return true;
            if (BoutonActive.Exists(b => b.Name == "b4") && BoutonActive.Exists(b => b.Name == "b5") && BoutonActive.Exists(b => b.Name == "b6"))
                return true;
            if (BoutonActive.Exists(b => b.Name == "b7") && BoutonActive.Exists(b => b.Name == "b8") && BoutonActive.Exists(b => b.Name == "b9"))
                return true;

            // Colonnes gagnantes
            if (BoutonActive.Exists(b => b.Name == "b1") && BoutonActive.Exists(b => b.Name == "b4") && BoutonActive.Exists(b => b.Name == "b7"))
                return true;
            if (BoutonActive.Exists(b => b.Name == "b2") && BoutonActive.Exists(b => b.Name == "b5") && BoutonActive.Exists(b => b.Name == "b8"))
                return true;
            if (BoutonActive.Exists(b => b.Name == "b3") && BoutonActive.Exists(b => b.Name == "b6") && BoutonActive.Exists(b => b.Name == "b9"))
                return true;

            // Diagonales gagnantes
            if (BoutonActive.Exists(b => b.Name == "b1") && BoutonActive.Exists(b => b.Name == "b5") && BoutonActive.Exists(b => b.Name == "b9"))
                return true;
            if (BoutonActive.Exists(b => b.Name == "b3") && BoutonActive.Exists(b => b.Name == "b5") && BoutonActive.Exists(b => b.Name == "b7"))
                return true;

            if (BoutonActive.Count == 9)
            {
                MessageBox.Show("Partie nulle ! Recommençons.");
                ViderBoutonActive(); // Réinitialiser les boutons actifs du joueur en cas de partie nulle
                return true; // Renvoyer true pour indiquer que la partie est nulle
            }

            return false;
        }

        // Fonction qui fait augmenter le crédit
        public void IncrementerCredit()
        {
            //Partie.nombreCredits++;
            this.credit += 3;
        }

        public int CreditList()
        {
            return Partie.nombreCredits;
        }


        public string informationJoueur()
        {
            return $"Joueur : {this.pseudo}, " +
                        $"\t \n Symbole: {this.symbole}, " +
                         $"\t \n Titre actuel: le {JoueurScore()}" +
                       $"\t \n Crédit: {this.credit}";
        }

        public string JoueurEnCours()
        {
            return $"En attente de {pseudo}, le {JoueurScore()} ... ";
        }

        // Titres assignés au joueur actif tout au long de la partie
        public string JoueurScore()
        {
            if (credit == 0)
            {
                return "bébé grenouille";
            }
            else if (credit == 3)
            {
                return $"Débutant du {symbole}";
            }
            else if(credit == 6)
            {
                return "Chaton du tictactoe";
            }
            else if (credit == 9)
            {
                return $"Maîtrise un peu le {symbole}";
            }
            else if (credit == 12)
            {
                return $"Tigre du tictactoe";
            }
            else if (credit == 15)
            {
                return $"{symbole} devient légal";
            }
            else if (credit == 18)
            {
                return $"{symbole} devient le maire de sa ville";
            }
            else if (credit == 21)
            {
                return $"{symbole} devient le ministre du pays";
            }
            else if (credit == 24)
            {
                return $"Président du {symbole} ";
            }
            else if (credit == 27)
            {
                return $"Roi du {symbole} ";
            }
            else if (credit >= 30)
            {
                return $"Maître suprême du {symbole} ";
            }

            return JoueurScore();
        }

    }
}
