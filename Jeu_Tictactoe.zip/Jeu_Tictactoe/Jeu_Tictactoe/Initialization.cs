﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Jeu_Tictactoe.Jeu;

namespace Jeu_Tictactoe
{
    public partial class Initialization : Form
    {
        private List<Button> listeBoutons; // Déclaration de la liste

        public Initialization()
        {
            InitializeComponent();
            buttonDemarrer.Click += buttonDemarrer_Click_1; //Après avoir appuyé sur ce bouton, la fenêtre de jeu s'ouvre
        }

        // Initialisation du bouton Démarrer
        private void buttonDemarrer_Click_1(object sender, EventArgs e)
        {
            string pseudo1 = Pseudo1.Text;
            string pseudo2 = Pseudo2.Text;
            Joueur joueur1;
            Joueur joueur2 ;

            if (radioButtonX.Checked)
            {
                joueur1 = new Joueur('X', pseudo1);
                joueur2 = new Joueur('O', pseudo2);
            }
            else if (radioButtonO.Checked)
            {
                joueur1 = new Joueur('O', pseudo1);
                joueur2 = new Joueur('X', pseudo2);
            }
            else
            {
                MessageBox.Show("Veuillez choisir un signe pour " + Pseudo1.Text + ".", "Choix du signe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Faire montrer le jeu
            Jeu jeu = new Jeu(new PartieEnCours(joueur1, joueur2));
            jeu.Show();

            // Boucle d'exécution continue pour gérer les évenements
            while (!jeu.IsDisposed) // Vérifie si le formulaire du jeu a été fermé
            {
                System.Windows.Forms.Application.DoEvents(); // Gérer les événements
            }

            // Fermer la fenêtre d'initialisation et afficher la fenêtre du jeu
            this.Close();
        }



        // Boutons Inutiles dus au MISSCLICK
        private void radioButtonO_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void radioButtonX_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void tictactoe_Load(object sender, EventArgs e)
        {
        }
        private void Pseudo1_TextChanged(object sender, EventArgs e)
        {
        }
        private void Pseudo2_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
