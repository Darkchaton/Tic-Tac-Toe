﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jeu_Tictactoe
{
    public interface Ijoueur
    {
        //Déclaration
          bool estGagnant(List<Button> listeBoutons);
          string Pseudo { get; }
          string informationJoueur();
          int Credit { get; set; }
          List<Button> BoutonActive { get; }
          char Symbole { get; set; }
    }
}
