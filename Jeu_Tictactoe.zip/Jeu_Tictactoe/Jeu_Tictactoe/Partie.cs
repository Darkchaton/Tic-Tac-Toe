﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jeu_Tictactoe
{

    public struct PartieEnCours
    {
        // Declaration
        public Joueur Joueur1;
        public Joueur Joueur2;
        public Joueur JoueurActif;
        public string PseudoGagnant;
        public int credits;
        public PartieEnCours(Joueur j1 , Joueur j2)
        {
            this.Joueur1 = j1;
            this.Joueur2 = j2;
            this.JoueurActif = j1;
            this.PseudoGagnant = " ";
            this.credits = 0;
        }

        //Les informations entrées par le joueur
        //Ce qui devrait nous permettre de dire qui est entrain de jouer et quel est le tour de qui
        public string informationPartie()
        {
            //string infoPartie = 
            string PseudoJoueur1 = Joueur1.Pseudo;
            string PseudoJoueur2 = Joueur2.Pseudo;
            char SymboleJoueur1 = Joueur1.Symbole;
            char SymboleJoueur2 = Joueur2.Symbole;
            string TJoueur1 = Joueur1.JoueurScore();
            string TJoueur2 = Joueur2.JoueurScore();

             int CJ1 = Joueur1.CreditList();

            string infoJoueurActif = JoueurActif.JoueurEnCours();

            string infoPartie = $"Joueur 1:\n *Pseudo: {PseudoJoueur1} \n *Symbole: {SymboleJoueur1} \n *Titre: {TJoueur1} \n *Credit: {CJ1}"  +

                                           $"\n\nJoueur 2:\n *Pseudo: { PseudoJoueur2} \n *Symbole: { SymboleJoueur2} \n *Titre: { TJoueur2} \n" +

                                           $"\n\nJoueur gagnant: {JoueurActif.Pseudo} ! \n\n";

            return infoPartie;
        }
    }
    public static class Partie 
    {
        // Déclaration d'une liste qui gardera chaque partie jouée et fera donc office d'Historique
        public static List<PartieEnCours> historiquePartie = new List<PartieEnCours>();
        public static int nombrePartieJouees = 0; //Nombre de parties gardées
        public static int nombreCredits = 0;

        // Garde les informations de l'Historique
        public static string InformationHistorique()
        {
            string informationHistorique = string.Empty; //Retourne une chaîne de strings qui sera affichés dans un MessageBox
            int p = 0; // Initialiser le nombre de parties AFFICHÉES dans l'historique

            foreach (PartieEnCours partieEnCours in historiquePartie)
            {
                string infoPartie = partieEnCours.informationPartie();
                int infoPartieC = partieEnCours.credits;
                informationHistorique += $"Historique de la partie {p++} \n {infoPartie}\n\n";
            }

            return informationHistorique;
        }

    }
}
